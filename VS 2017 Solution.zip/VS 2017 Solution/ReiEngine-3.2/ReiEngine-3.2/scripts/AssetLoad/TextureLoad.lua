-- Asset Loading
TextureMap = { 
	TEST = "SPR_Default.png",
	BOB = "SPR_RockLee.png"
}