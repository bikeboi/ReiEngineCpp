Tree = 
{
	Pac_Background = 
	{
		class = "bg",
		x = 0, y = 0, sX = 20, sY = 20,
		children = 
		{
			Bob = 
			{
				class = "bobtype",
				x = 200,
				y = 100,
				sX = 2,
				sY = 2
			},
			WallTop = 
			{
				class = "wall_v",
				x = 0, y = 52
			},
			SceneListener = 
			{
				class = "scene_2_listener"
			}
		}
	}
	
}

function Update()

end